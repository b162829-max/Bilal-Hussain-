# Driver Accounts

Modern Blue, English-language Android driver accounts app.

## Build APK on GitHub
1. Upload the extracted project files to the repository root (keep the `.github` folder).
2. Open **Actions** and run **Build Driver Accounts APK**.
3. Download the **Driver-Accounts-APK** artifact.

The workflow uses Java 17, Android SDK 35, Android Gradle Plugin 8.7.3 and Gradle 8.9.

Default login: username `BILAL`, PIN `8484`. Change these credentials in the app after login.

Entries are stored locally on the phone. Use Backup regularly.
