# Driver Accounts

English-language Android driver accounts app with Black & Gold as the default theme.
Optional themes: Blue & White and Purple & White. Profile photo is stored locally on the device.

## Build APK on GitHub
1. Upload the extracted project files to the repository root (keep the `.github` folder).
2. Open **Actions** and run **Build Driver Accounts APK**.
3. Download the **Driver-Accounts-APK** artifact.

The workflow uses Java 17, Android SDK 35, Android Gradle Plugin 8.7.3 and Gradle 8.9.
Default login: username `BILAL`, PIN `8484`. Change these credentials in the app after login.
Entries and profile photo are stored locally on this phone. Use Backup regularly.
